﻿#Requires AutoHotkey v1.1
#NoEnv
#SingleInstance, force
SetWorkingDir %A_ScriptDir%
#Include %A_ScriptDir%\Resources\Gdip_All.ahk
SetKeyDelay, 0, 50

ver := "1.07" 

; --- Auto-Update Check ---
#Include %A_ScriptDir%\Resources\Updater.ahk

updateResult := CheckForUpdate(ver)
if (updateResult = 2) {
    Reload
}

MultiInstanceTools := "RobloxAccountManager.exe,Roblox Account Manager.exe,RAM.exe,RobloxMulti.exe,MultiRoblox.exe,MultipleRoblox.exe,Multiple Roblox.exe,Bloxstrap.exe"

Loop, Parse, MultiInstanceTools, `,
{
    Process, Exist, %A_LoopField%
    if (ErrorLevel > 0)
    {
        MsgBox, 48, Error,
        (
Conflicting program detected:
%A_LoopField%

For this script to work properly, please close all Roblox multi-client utilities.
Please close them and try again.
        )
        ExitApp
    }
}


pToken := Gdip_Startup()
OnExit, CleanupGdip


global AppDataOpt := A_AppData "\Ultimate_Macro\Macros\TDSMacro\Options"
global LocalSettingsPath := A_WorkingDir "\Settings.tds"
global AppDataSettingsPath := AppDataOpt "\Settings.tds"
global RecordingsDir := A_AppData "\Ultimate_Macro\Macros\TDSMacro\Recordings"
global StateFile := A_AppData "\Ultimate_Macro\Macros\TDSMacro\state.ini"
global ShowIndicators := true

IfNotExist, %AppDataOpt%
    FileCreateDir, %AppDataOpt%
IfNotExist, %RecordingsDir%
    FileCreateDir, %RecordingsDir%

if FileExist(AppDataSettingsPath)
    global SettingsFile := AppDataSettingsPath
else
    global SettingsFile := LocalSettingsPath


IniRead, VipLink, %SettingsFile%, Options, VipLink, %A_Space%
IniRead, tempVip, %SettingsFile%, Options, UseVipServer, OFF
UseVipServer := (tempVip = "ON" || tempVip = "1") ? "ON" : "OFF"

SyncSettings()

global MapDetectorPath := AppDataOpt "\map_detector\map_detector.exe"
global TargetFolder := AppDataOpt "\map_detector"

if !FileExist(MapDetectorPath) {
    Gui, Progress:New, +AlwaysOnTop -Caption +Border
    Gui, Color, 1E1E1E
    
    Gui, Add, Progress, x10 y10 w280 h20 Background333333 c3A86FF vProgressBar, 0
    
    Gui, Font, s10 w400 cFFFFFF, Segoe UI
    Gui, Add, Text, x10 y40 w280 h20 Center vStatusText, Starting download...
    
    Gui, Font, s9 w400 c888888
    Gui, Add, Text, x10 y65 w280 h20 Center, TDS Macro - Installing Dependencies
    
    Gui, Show, w300 h95, TDS Macro
    
    OnMessage(0x0201, "WM_LBUTTONDOWN_Progress")
    
    Sleep, 500
    
    ZipPath := A_Temp "\map_detector.zip"
    
    if FileExist(ZipPath)
        FileDelete, %ZipPath%
        
    if InStr(FileExist(TargetFolder), "D")
        FileRemoveDir, %TargetFolder%, 1
    
    GuiControl,, StatusText, Downloading map_detector.zip...
    GuiControl,, ProgressBar, 25
    
    try {
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", "https://github.com/DarksenDev/tds-macro/releases/download/asd/map_detector.zip", true)
        whr.Option(6) := 1
        whr.Send()
        whr.WaitForResponse()
        
        if (whr.Status != 200)
            throw
            
        ADO := ComObjCreate("ADODB.Stream")
        ADO.Type := 1
        ADO.Open()
        ADO.Write(whr.ResponseBody)
        ADO.SaveToFile(ZipPath, 2)
        ADO.Close()
    } catch {
        UrlDownloadToFile, https://github.com/DarksenDev/tds-macro/releases/download/asd/map_detector.zip, %ZipPath%
    }
    
    if !FileExist(ZipPath) {
        Gui, Progress:Destroy
        MsgBox, 48, Error, Failed to download map_detector.zip! Check your internet connection.
        ExitApp
    }
    
    FileGetSize, zipSize, %ZipPath%, K
    if (zipSize < 1) {
        Gui, Progress:Destroy
        MsgBox, 48, Error, Downloaded file is corrupted or empty!
        ExitApp
    }
    
    GuiControl,, StatusText, Extracting files...
    GuiControl,, ProgressBar, 75
    
    FileCreateDir, %TargetFolder%
    
    extractCmd := ComSpec " /c tar -xf """ ZipPath """ -C """ TargetFolder """"
    RunWait, %extractCmd%, , Hide
    
    NestedFolder := TargetFolder "\map_detector"
    if InStr(FileExist(NestedFolder), "D") {
        Loop, Files, %NestedFolder%\*, D
        {
            FileMoveDir, %A_LoopFileFullPath%, %TargetFolder%\%A_LoopFileName%, 1
        }
        Loop, Files, %NestedFolder%\*, F
        {
            FileMove, %A_LoopFileFullPath%, %TargetFolder%\*, 1
        }
        Sleep, 500
        FileRemoveDir, %NestedFolder%, 1
    }
    
    GuiControl,, StatusText, Cleaning up...
    GuiControl,, ProgressBar, 90
    Sleep, 500
    
    if FileExist(ZipPath)
        FileDelete, %ZipPath%
    
    if !FileExist(MapDetectorPath) {
        Gui, Progress:Destroy
        MsgBox, 48, Error, Failed to install map_detector.exe!`n`nPlease temporarily disable your Antivirus or Windows Defender and try again.
        ExitApp
    }
    
    GuiControl,, StatusText, Installation complete!
    GuiControl,, ProgressBar, 100
    Sleep, 1000
    Gui, Progress:Destroy
}


WM_LBUTTONDOWN_Progress() {
    PostMessage, 0xA1, 2,,, A
}

global LogLines := []                
global OverlayHWND                   
global OverlayBitmap                 
global OverlayGraphics               
global OverlayWidth := 500
global OverlayHeight := 200
global OverlayX := 1400
global OverlayY := 820

global ChainKey, BeatKey, CaravanKey, TimeScaleMode, UseTimeScale, TimeScaleMultiplier
IniRead, ChainKey, %SettingsFile%, Hotkeys, Chain, C
IniRead, BeatKey, %SettingsFile%, Hotkeys, Beat, B
IniRead, CaravanKey, %SettingsFile%, Hotkeys, Caravan, J
IniRead, TimeScaleMode, %SettingsFile%, Options, TimeScaleMode, OFF
global DebugConsole := "OFF"              
IniRead, DebugConsole, %SettingsFile%, Options, DebugConsole, ON  
if (DebugConsole = 1)
    DebugConsole := "ON"
else if (DebugConsole = 0)
    DebugConsole := "OFF"

if (TimeScaleMode = "1.5x") {
    UseTimeScale := true, TimeScaleMultiplier := 1.5
} else if (TimeScaleMode = "2x") {
    UseTimeScale := true, TimeScaleMultiplier := 2
} else {
    UseTimeScale := false, TimeScaleMultiplier := 1
}

if (DebugConsole = "ON")
    ShowDebugConsole()

global map := "", difficulty := "", requiredTowers := ""
global autoChain := "OFF", autoCaravan := "OFF", autoDropTheBeat := "OFF"
global Commander := false, AutoSkip := "ON"

global MoveEnabled := false, MoveDirection := "W", MoveDuration := 750
global unfocusX := 150, unfocusY := 200
global Towers := {}, RecordedSteps := [], Recording := false, RunningStrategy := false
global chainInterval := 10, caravanInterval := 20
global modifiers := ""
global LastDisconnectCheck := 0

IconPath := A_WorkingDir "\icon.ico"
if FileExist(IconPath)
    Menu, Tray, Icon, %IconPath%

IniRead, autoRun, %StateFile%, State, Running, 0
IniRead, autoStrat, %StateFile%, State, Strategy, %A_Space%

if (autoRun = 1 && autoStrat != "" && FileExist(autoStrat)) {
    LoadStrategyFile(autoStrat)
    GuiControl,, CurrentStrat, %autoStrat%
    Gui, Main:Hide
    RunningStrategy := true
    WinActivate, ahk_exe RobloxPlayerBeta.exe
    RunStrategy()
    RunningStrategy := false
    Gui, Main:Show
    IniWrite, 0, %StateFile%, State, Running
}

OnMessage(0x0201, "WM_LBUTTONDOWN")
WM_LBUTTONDOWN() {
    PostMessage, 0xA1, 2,,, A
}

Gui, Main:New, +LastFound +AlwaysOnTop -Caption +Border
Gui, Color, 121212

Gui, Add, Progress, x0 y0 w400 h3 Background3A86FF vAccent, 0 

if FileExist(IconPath)
    Gui, Add, Picture, x20 y20 w32 h32, %IconPath%

Gui, Font, s16 w600 cFFFFFF, Bahnschrift
Gui, Add, Text, x65 y22 w200 vTitle, TDS MACRO

Gui, Font, s14 w400 cFFFFFF, Segoe UI

Gui, Add, Text, x295 y18 gShowFAQ +Center w25 h25, ?
Gui, Add, Text, x335 y18 gMinimizeMain +Center w25 h25, —
Gui, Add, Text, x365 y18 gOpenSettings +Center w25 h25, ⚙

Gui, Add, Progress, x20 y65 w360 h1 Background333333, 0

Gui, Font, s9 w600 c3A86FF, Bahnschrift
Gui, Add, Text, x25 y85, STRATEGIES (.STRAT files)

Gui, Font, s10 w400 cFFFFFF, Consolas
Gui, Add, Text, x25 y110 w275 h26 vCurrentStrat Right +0x400000 Background2A2A2A cWhite

Gui, Font, s9 w400, Bahnschrift
Gui, Add, Button, x310 y109 w65 h28 gSelectStrat, BROWSE

Gui, Font, s11 w600 cFFFFFF, Bahnschrift
Gui, Add, Button, x25 y160 w170 h45 gStartStrategy Default, START STRATEGY
Gui, Add, Button, x205 y160 w170 h45 gStartRecordGUI, RECORD

Gui, Font, s9 w400, Bahnschrift
Gui, Add, Button, x25 y215 w350 h32 gStopRecord vStopButton Hidden, STOP RECORDING

Gui, Font, s8 w400 c444444, Segoe UI
Gui, Add, Text, x0 y260 w400 Center, PRESS ESC TO EXIT
Gui, Show, w400 h285, TDS Macro
return


IniRead, autoRun, %StateFile%, State, Running, 0
IniRead, autoStrat, %StateFile%, State, Strategy, %A_Space%
if (autoRun = 1 && autoStrat != "" && FileExist(autoStrat)) {
    Gui, Main:Hide
    LoadStrategyFile(autoStrat)
    RunningStrategy := true
    WinActivate, ahk_exe RobloxPlayerBeta.exe
    RunStrategy()
    RunningStrategy := false
    Gui, Main:Show
    IniWrite, 0, %StateFile%, State, Running
}

#If RunningStrategy
    Esc::
        DeleteAllIndicators()
        IniWrite, 0, %StateFile%, State, Running
        Reload
    return
#If

Esc::
    ExitApp
^r::Reload

ShowFAQ:
    faqText := "Go to my Discord Server to see the FAQ"
    ModernMsgBox("FAQ", faqText, "OK", "Blue")
return

StartStrategy:
    Gui, Main:Submit, NoHide
    GuiControlGet, stratText,, CurrentStrat
    if (stratText != "") {
        stratFile := stratText
        if !FileExist(stratFile) {
            ModernMsgBox("Error", "Strategy file not found:`n" stratFile, "OK", "Red")
            return
        }
        LoadStrategyFile(stratFile)
        if (requiredTowers != "")
            ModernMsgBox("Required Towers", requiredTowers, "OK", "Blue")
        IniWrite, 1, %StateFile%, State, Running
        IniWrite, %stratFile%, %StateFile%, State, Strategy
        Gui, Main:Hide
        RunningStrategy := true
        RunStrategy()
    }
    else {
        ModernMsgBox("Warning", "Select a strategy file first!", "OK", "Red")
    }
return

SelectStrat:
    FileSelectFile, stratFile, 3, %RecordingsDir%, Select strategy file, Strategy (*.strat)
    if (stratFile != "") {
        GuiControl,, CurrentStrat, %stratFile%
        LoadStrategyFile(stratFile)
    }
return

StartRecordGUI:
    ShowSettingsGUI()
return

StopRecord:
    if (!Recording)
        return
    Recording := false
    Gui, Main:Font, s16 w600 cFFFFFF, Bahnschrift
    GuiControl, Main:Font, Title
    GuiControl, Main:, Title, TDS MACRO
    GuiControl, Main:Hide, StopButton

    DeleteAllIndicators()
    if (ModernMsgBox("Save", "Save the recorded strategy?", "YES|NO", "Blue") = "YES")
    {
        InputBox, fileName, Save, File name (without .strat):,,,,,,,,MyStrategy
        if ErrorLevel
        {
            Gui, Main:Show
            return
        }
        filePath := RecordingsDir . "\" . fileName . ".strat"
        FileDelete, %filePath%
        FileAppend, [Settings]`nmap=%map%`ndifficulty=%difficulty%`nrequiredTowers=%requiredTowers%`nmodifiers=%modifiers%`nchainInterval=%chainInterval%`ncaravanInterval=%caravanInterval%`nautoChain=%autoChain%`nautoCaravan=%autoCaravan%`nautoDropTheBeat=%autoDropTheBeat%`nautoSkip=%AutoSkip%`nmoveEnabled=%MoveEnabled%`nmoveDirection=%MoveDirection%`nmoveDuration=%MoveDuration%`n`n[Steps]`n, %filePath%
        for i, step in RecordedSteps
            FileAppend, %step%`n, %filePath%
        LogToConsole("Strategy saved: " . filePath)
        GuiControl,, CurrentStrat, %filePath%
    }
    else
    {
        LogToConsole("Recording cancelled, strategy not saved")
        GuiControl,, CurrentStrat, (recording cancelled)
    }
    Gui, Main:Show
return

MinimizeMain:
    Gui, Main:Minimize
return


OpenSettings:
    Gui, Settings:New, +AlwaysOnTop -Caption +Border +OwnerMain
    Gui, Color, 1A1A1A, 2A2A2A 
    Gui, Add, Progress, x0 y0 w340 h2 Background3A86FF, 0
    Gui, Font, s12 w600 cFFFFFF, Bahnschrift
    Gui, Add, Text, x20 y15 w300, SETTINGS

    Gui, Font, s10 w400 c888888, Bahnschrift
    Gui, Add, Text, x20 y55, Commander (Call of Arms):
    Gui, Font, s10 w600 cFFFFFF
    Gui, Add, Edit, x220 y52 w60 h24 vChainKey Center -E0x200, %ChainKey%
    Gui, Add, Button, x290 y51 w30 h26 gHelpChain, ?

    Gui, Font, s10 w400 c888888
    Gui, Add, Text, x20 y95, DJ (Drop The Beat):
    Gui, Font, s10 w600 cFFFFFF
    Gui, Add, Edit, x220 y92 w60 h24 vBeatKey Center -E0x200, %BeatKey%
    Gui, Add, Button, x290 y91 w30 h26 gHelpBeat, ?

    Gui, Font, s10 w400 c888888
    Gui, Add, Text, x20 y135, Support Caravan:
    Gui, Font, s10 w600 cFFFFFF
    Gui, Add, Edit, x220 y132 w60 h24 vCaravanKey Center -E0x200, %CaravanKey%
    Gui, Add, Button, x290 y131 w30 h26 gHelpCaravan, ?

    Gui, Font, s10 w400 c888888
    Gui, Add, Text, x20 y175, Timescale:
    Gui, Add, DropDownList, x160 y172 w80 vTimeScaleMode, OFF|1.5x|2x
    GuiControl, ChooseString, TimeScaleMode, %TimeScaleMode%
    Gui, Font, s9 w400 cFFFFFF
    Gui, Add, Button, x250 y171 w70 h26 gHelpTimeScale, INFO

    Gui, Font, s10 w400 c888888
    Gui, Add, Text, x20 y215, VIP Server Link:
    Gui, Font, s9 w400 cFFFFFF
    Gui, Add, Edit, x20 y240 w300 h24 vVipLink -E0x200 gCheckVipLink, %VipLink%

    vVal := (UseVipServer = "ON") ? 1 : 0
    Gui, Add, Checkbox, x20 y280 w16 h16 vUseVipServer Checked%vVal% gCheckVipLink
    Gui, Font, s10 w400 c888888 q3, Bahnschrift
    Gui, Add, Text, x42 y281 gClickVipLabel, Use VIP Server

    dcChecked := (DebugConsole = "ON") ? 1 : 0
    Gui, Add, Checkbox, x170 y280 w16 h16 vDebugConsole Checked%dcChecked%
    Gui, Font, s10 w400 c2e7d04 q3
    Gui, Add, Text, x192 y281 gClickDebugLabel, Debug Console

    Gui, Font, s11 w600 cFFFFFF
    Gui, Add, Button, x20 y335 w300 h40 gSaveSettings Default, SAVE CHANGES
    
    GoSub, CheckVipLink
    Gui, Show, w340 h400, Hotkey & TimeScale Settings
return

ClickVipLabel:
    Gui, Settings:Submit, NoHide
    if (VipDisabled)
    {
        MsgBox, 0x1010, Error, VIP Link is invalid or empty!
        return
    }
    GuiControl,, UseVipServer, % !UseVipServer
return

ClickDebugLabel:
    Gui, Settings:Submit, NoHide
    GuiControl,, DebugConsole, % !DebugConsole
return

CheckVipLink:
    Gui, Settings:Submit, NoHide
    
    str := Trim(VipLink)
    
    if (StrLen(str) = 0) {
        VipDisabled := false
        GuiControl, Enable, UseVipServer
        return
    }
    
    RegExMatch(str, "i)roblox\.com\/([a-z]{2}\/)?games\/3260590327\/?([^\/]*)\?privateServerLinkCode=(?<code>[a-z0-9]{32})", NewPrivLink)
    RegExMatch(str, "i)roblox\.com\/share\?code=(?<code>[a-f0-9]{32})", NewShareCode)
    
    if (NewShareCodeCode != "") {
        link := "https://www.roblox.com/share?code=" . NewShareCodeCode . "&type=Server"
        
        wr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        wr.Open("GET", link, 1)
        wr.Send()
        
        if !(wr.WaitForResponse(3000)) || wr.Status != 200 || !InStr(wr.ResponseText, "roblox:start_place_id") {
            MsgBox, 16, Failed to fetch link, The link could not be fetched.`nMake sure you are using a valid Share Code link and that you copied the entire link.`n`nIt's also possible that Roblox is down.
            goto LinkInvalid
        }
        
        if !InStr(wr.ResponseText, "content=""3260590327""") {
            MsgBox, 16, Invalid Share Code, Your link is not for Tower Defense Simulator.
            goto LinkInvalid
        }
        
        VipDisabled := false
        GuiControl, Enable, UseVipServer
        return
        
    } else if (NewPrivLinkCode != "") {
        VipDisabled := false
        GuiControl, Enable, UseVipServer
        return
        
    } else {
        MsgBox, 16, Invalid Private Server Link, Make sure your link is:`n- copied correctly and completely`n- for Tower Defense Simulator
        goto LinkInvalid
    }
    
LinkInvalid:
    VipDisabled := true
    GuiControl,, UseVipServer, 0
    GuiControl, Disable, UseVipServer
return


SaveSettings:
    Gui, Settings:Submit, NoHide
    ChainKey   := SubStr(RegExReplace(ChainKey,   "\s", ""), 1, 1)
    BeatKey    := SubStr(RegExReplace(BeatKey,    "\s", ""), 1, 1)
    CaravanKey := SubStr(RegExReplace(CaravanKey, "\s", ""), 1, 1)
    if (ChainKey = "")
        ChainKey := "C"
    if (BeatKey = "")
        BeatKey := "B"
    if (CaravanKey = "")
        CaravanKey := "J"
    if (TimeScaleMode = "")
        TimeScaleMode := "OFF"

    IniWrite, %ChainKey%, %SettingsFile%, Hotkeys, Chain
    IniWrite, %BeatKey%, %SettingsFile%, Hotkeys, Beat
    IniWrite, %CaravanKey%, %SettingsFile%, Hotkeys, Caravan
    IniWrite, %TimeScaleMode%, %SettingsFile%, Options, TimeScaleMode
    IniWrite, %VipLink%, %SettingsFile%, Options, VipLink

    if (UseVipServer = 1)
        IniWrite, ON, %SettingsFile%, Options, UseVipServer
    else
        IniWrite, OFF, %SettingsFile%, Options, UseVipServer

    if (DebugConsole = 1)
        IniWrite, ON, %SettingsFile%, Options, DebugConsole
    else
        IniWrite, OFF, %SettingsFile%, Options, DebugConsole

    if (TimeScaleMode = "1.5x") {
        UseTimeScale := true, TimeScaleMultiplier := 1.5
    } else if (TimeScaleMode = "2x") {
        UseTimeScale := true, TimeScaleMultiplier := 2
    } else {
        UseTimeScale := false, TimeScaleMultiplier := 1
    }

    if (DebugConsole = 1) {
        DebugConsole := "ON"
        ShowDebugConsole()
    } else {
        DebugConsole := "OFF"
        HideDebugConsole()
    }

    SyncSettings()
    Gui, Settings:Destroy
return

HelpChain:
ModernMsgBox("Info", "Configure hotkey for Commander's 'Call of Arms'.", "OK", "Blue")
return
HelpBeat:
ModernMsgBox("Info", "Configure hotkey for DJ's 'Drop The Beat'.", "OK", "Blue")
return
HelpCaravan:
ModernMsgBox("Info", "Configure hotkey for the 'Support Caravan'.", "OK", "Blue")
return
HelpTimeScale:
    ModernMsgBox("TimeScale Info", "1.5x — more stable and recommended for most cases.`n2x — requires special strategies but is much more effective.", "OK", "Blue")
return


SettingsGuiEscape:
    Gui, Settings:Destroy
return


ShowSettingsGUI() {
    global
    Gui, StrategySettings:New, +AlwaysOnTop -Caption +Border +LastFound, Strategy Setup
    Gui, Color, 1A1A1A, 2A2A2A 
    
    Gui, Add, Progress, x0 y0 w400 h2 Background3A86FF, 0

    Gui, Font, s12 w600 cFFFFFF, Bahnschrift
    Gui, Add, Text, x20 y15 w380 Center, STRATEGY CONFIGURATION

    Gui, Font, s9 w600 c3A86FF, Bahnschrift
    Gui, Add, Text, x20 y55, MAIN PARAMETERS
    Gui, Add, Progress, x20 y75 w400 h1 Background333333, 0

    Gui, Font, s10 w400 c888888, Bahnschrift
    Gui, Add, Text, x25 y85, Map:
    Gui, Add, Text, x25 y120, Difficulty:
    Gui, Add, Text, x25 y155, Towers:
    Gui, Add, Text, x25 y190, Modifiers:

    Gui, Font, s10 w600 cFFFFFF
    Gui, Add, Edit, x120 y82 w210 h24 vMap -E0x200 Center, %map%
    Gui, Font, s10 w400 c888888, Bahnschrift
    Gui, Add, DropDownList, x120 y117 w210 vDifficulty, Easy|Casual|Intermediate|Molten|Fallen|Frost|Hardcore|Voidcore|Pizza Party|Badlands II|Polluted Wastelands II
    GuiControl, ChooseString, Difficulty, %difficulty%
    Gui, Font, s10 w600 cFFFFFF    
    Gui, Add, Edit, x120 y152 w210 h24 vRequiredTowers -E0x200 Center, %requiredTowers%
    Gui, Add, Edit, x120 y187 w210 h24 vModifiers -E0x200 Center, %modifiers%

    Gui, Font, s9 w600 c3A86FF, Bahnschrift
    Gui, Add, Text, x20 y230, AUTOMATION & FEATURES
    Gui, Add, Progress, x20 y250 w400 h1 Background333333, 0

    Gui, Font, s10 w400 cFFFFFF, Bahnschrift
    Gui, Add, Checkbox, x25 y265 vAutoChain Checked%autoChain%, Auto-Chain
    Gui, Add, Text, x175 y265 c888888, Interval:
    Gui, Add, Edit, x255 y262 w75 h22 vChainInterval -E0x200 Center, %chainInterval%

    Gui, Add, Checkbox, x25 y295 vAutoCaravan Checked%autoCaravan%, Auto-Caravan
    Gui, Add, Text, x175 y295 c888888, Interval:
    Gui, Add, Edit, x255 y292 w75 h22 vCaravanInterval -E0x200 Center, %caravanInterval%

    Gui, Add, Checkbox, x25 y325 vAutoDropTheBeat Checked%autoDropTheBeat%, Auto-Drop Beat (DJ)
    
    Gui, Add, Checkbox, x25 y355 vAutoSkip Checked%AutoSkip%, Auto-Skip Waves

    Gui, Font, s10 w400 cFFFFFF, Bahnschrift
    Gui, Add, Checkbox, x25 y385 vMoveEnabled Checked%MoveEnabled%, Enable Move
    Gui, Add, Text, x150 y385 c888888, Dir:
    Gui, Add, DropDownList, x180 y382 w50 vMoveDirection, W||A||S||D
    GuiControl, ChooseString, MoveDirection, %MoveDirection%
    Gui, Add, Text, x240 y385 c888888, Dur (ms):
    Gui, Add, Edit, x300 y382 w50 h22 vMoveDuration -E0x200 Center, %MoveDuration%
    Gui, Add, Button, x355 y381 w22 h22 gHelpMove, ?

    Gui, Font, s11 w600 cFFFFFF, Bahnschrift
    Gui, Add, Button, x20 y430 w150 h45 gStrategySettingsOK Default, START RECORD
    Gui, Add, Button, x180 y430 w150 h45 gStrategySettingsCancel, CANCEL

    Gui, Show, w400 h505, Strategy Setup
    WinWaitClose, Strategy Setup
    return


    HelpMove:
        HelpText := "This movement will be applied at two points: when restarting for normal games (to adjust spawn), and after aligning camera."
        ModernMsgBox("Move Info", HelpText, "OK", "Blue")
    return

    StrategySettingsOK:
        Gui, StrategySettings:Submit
        map := Map
        difficulty := Difficulty
        requiredTowers := RequiredTowers
        autoChain := AutoChain ? "ON" : "OFF"
        autoCaravan := AutoCaravan ? "ON" : "OFF"
        autoDropTheBeat := AutoDropTheBeat ? "ON" : "OFF"
        AutoSkip := AutoSkip ? "ON" : "OFF"
        MoveEnabled := MoveEnabled ? true : false
        MoveDirection := MoveDirection
        MoveDuration := (MoveDuration is number) ? MoveDuration : 750
        if (MoveDirection != "W" and MoveDirection != "A" and MoveDirection != "S" and MoveDirection != "D")
            MoveDirection := "W"
        modifiers := Modifiers
        
        Commander := false
        Gui, StrategySettings:Destroy
        Recording := true
        RecordedSteps := []
        Towers := {}
        DeleteAllIndicators()

        Gui, Main:Font, s16 w600 cFF0000, Bahnschrift
        GuiControl, Main:Font, Title
        GuiControl, Main:, Title, TDS MACRO 🔴
        GuiControl, Main:Show, StopButton

        LogToConsole("Recording started:")
        LogToConsole("- MButton: place tower")
        LogToConsole("- Ctrl+U: upgrade")
        LogToConsole("- Ctrl+D: set DJ track")
        LogToConsole("- Ctrl+T: Align Camera")
        LogToConsole("- Ctrl+X: Sell Tower")
        LogToConsole("- Ctrl+B: Delete tower (Cancel)")
        LogToConsole("- Ctrl+X: Sell tower")

        ModernMsgBox("Recording", "Recording enabled:`n- MButton: place tower`n- Ctrl+U: upgrade`n- Ctrl+D: set DJ track`n- Ctrl+T: Align Camera`n- Ctrl+B: Delete tower (Cancel)`n- Ctrl+X: Sell tower", "OK", "Blue")
    return

    StrategySettingsCancel:
        Gui, StrategySettings:Destroy
    return
}


MButton::
    if (!Recording)
        return

    WinMinimize, TDS Macro
    MouseGetPos, mx, my
    InputBox, slot, Slot (1-5), Enter the tower slot number (1-5):,,,,,,,,1
    if ErrorLevel
        return
    suggestedID := GetNextNumericID()
    InputBox, towerID, Tower ID, Enter a specific tower id:,,,,,,,,%suggestedID%
    if ErrorLevel
        return
    slotX := (slot = 1 ? 800 : slot = 2 ? 890 : slot = 3 ? 980 : slot = 4 ? 1070 : 1160)
    slotY := 1000
    Click, %slotX%, %slotY%
    Sleep, 200
    Click, %mx%, %my%
    Sleep, 200
    RecordedSteps.Push("SpawnTower(" . mx . ", " . my . ", " . slot . ", " . towerID . ")")
    Towers[towerID] := {x: mx, y: my, slot: slot, level: 0}
    UpdateTowerIndicator(towerID)
    LogToConsole("Recorded tower " . towerID . " (slot " . slot . ")")
return

^u::
    MouseGetPos, mx, my
    closestID := FindClosestTower(mx, my)
    if (closestID != "") {
        Towers[closestID].level += 1
        UpdateTowerIndicator(closestID)
        if (Recording) {
            RecordedSteps.Push("UpgradeTower(" . closestID . ")")
            LogToConsole("Recorded upgrade tower " . closestID . " (level " . Towers[closestID].level . ")")
            if (Towers[closestID].level >= 2 && RegExMatch(closestID, "i)^Commander\d*$") && !Commander) {
                Commander := true
                if (!HasStep("Commander := true"))
                    RecordedSteps.Push("Commander := true")
                LogToConsole("Commander activated")
            }
        } else {
            LogToConsole("Tower " . closestID . " upgraded to level " . Towers[closestID].level)
        }
    } else {
        LogToConsole("Can't find the tower to upgrade")
    }
return

^d::
    WinMinimize, TDS Macro

    if (!Recording)
        return

    InputBox, track, DJ Track, Enter Track Color (Purple/Red/Green):,,,,,,,,Green
    if !ErrorLevel {
        RecordedSteps.Push("SetDJTrack(""" . track . """)")
        LogToConsole("Recorded DJ-track " . track)
    }
return

^b::
    if (!Recording)
        return
    MouseGetPos, mx, my
    closestID := FindClosestTower(mx, my)
    if (closestID != "") {
        if (Towers[closestID].hwnd) {
            hwnd := Towers[closestID].hwnd
            WinClose, ahk_id %hwnd%
            Gui, Tower%closestID%:Destroy
        }
        
        newSteps := []
        for i, step in RecordedSteps {
            if (RegExMatch(step, "i)^SpawnTower\s*\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*" . closestID . "\s*\)$"))
                continue
            if (RegExMatch(step, "i)^UpgradeTower\s*\(\s*" . closestID . "\s*\)$"))
                continue
            if (RegExMatch(step, "i)^SellTower\s*\(\s*" . closestID . "\s*\)$"))
                continue
            newSteps.Push(step)
        }
        RecordedSteps := newSteps
        
        Towers.Delete(closestID)
        
        LogToConsole("Deleted tower " . closestID . " and all related data")
    } else {
        LogToConsole("No tower found near cursor to delete")
    }
return

^x::
    if (!Recording)
        return
    MouseGetPos, mx, my
    closestID := FindClosestTower(mx, my)
    if (closestID != "") {
        if (Towers[closestID].hwnd) {
            hwnd := Towers[closestID].hwnd
            WinClose, ahk_id %hwnd%
            Gui, Tower%closestID%:Destroy
            Towers[closestID].hwnd := ""
        }
        
        RecordedSteps.Push("SellTower(" . closestID . ")")
        SellTower(closestID)
        
        newSteps := []
        for i, step in RecordedSteps {
            if (RegExMatch(step, "i)^SpawnTower\s*\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*" . closestID . "\s*\)$"))
                continue
            if (RegExMatch(step, "i)^UpgradeTower\s*\(\s*" . closestID . "\s*\)$"))
                continue
            newSteps.Push(step)
        }
        RecordedSteps := newSteps
        
        Towers.Delete(closestID)
        
        LogToConsole("Recorded sell tower " . closestID)
    } else {
        LogToConsole("No tower found near cursor to sell")
    }
return

^t::AlignCamera()

LoadStrategyFile(file) {
    global
    Towers := {}
    RecordedSteps := []
    DeleteAllIndicators()
    IniRead, map, %file%, Settings, map, %A_Space%
    IniRead, difficulty, %file%, Settings, difficulty, %A_Space%
    IniRead, requiredTowers, %file%, Settings, requiredTowers, %A_Space%
    IniRead, autoChain, %file%, Settings, autoChain, OFF
    IniRead, autoCaravan, %file%, Settings, autoCaravan, OFF
    IniRead, autoDropTheBeat, %file%, Settings, autoDropTheBeat, OFF
    IniRead, AutoSkip, %file%, Settings, autoSkip, ON

    IniRead, moveDown, %file%, Settings, moveDown, false   
    IniRead, tempEnabled, %file%, Settings, moveEnabled, ""
    IniRead, tempDir, %file%, Settings, moveDirection, ""
    IniRead, tempDur, %file%, Settings, moveDuration, ""

    if (tempEnabled != "") {
        MoveEnabled := (tempEnabled = "true" or tempEnabled = "1") ? true : false
        MoveDirection := (tempDir != "" and (tempDir = "W" or tempDir = "A" or tempDir = "S" or tempDir = "D")) ? tempDir : "W"
        MoveDuration := (tempDur is number) ? tempDur : 750
    } else {
        if (moveDown = "true") {
            MoveEnabled := true
            MoveDirection := "S"
            MoveDuration := 750
        } else {
            MoveEnabled := false
            MoveDirection := "W"
            MoveDuration := 750
        }
    }

    IniRead, tempChain, %file%, Settings, chainInterval, 10
    IniRead, tempCaravan, %file%, Settings, caravanInterval, 20
    IniRead, modifiers, %file%, Settings, modifiers, %A_Space%
    if tempChain is number
        chainInterval := tempChain
    else
        chainInterval := 10
    if tempCaravan is number
        caravanInterval := tempCaravan
    else
        caravanInterval := 20
    Commander := false
    Loop, Read, %file%
    {
        if (A_LoopReadLine ~= "^\s*\[Settings\]" or A_LoopReadLine ~= "^\s*\[Steps\]")
            continue
        if (A_LoopReadLine != "")
            RecordedSteps.Push(A_LoopReadLine)
    }
}

RunStrategy() {
    global RunningStrategy, difficulty, MoveEnabled, MoveDirection, MoveDuration, unfocusX, unfocusY, UseTimeScale, TimeScaleMultiplier, TimeScaleMode, SettingsFile, requiredTowers, modifiers
    if (RunningStrategy != true)
        return

    LastDisconnectCheck := A_TickCount

    LogToConsole("Starting strategy...")
    LogToConsole("Map = " map)
    LogToConsole("Mode = " difficulty)
    LogToConsole("Timescale = " TimeScaleMode)
    LogToConsole("Required Towers: " requiredTowers)
    if (modifiers != "") {
        LogToConsole("Modifiers: " modifiers)
    }

    if (difficulty != "Hardcore" and difficulty != "Voidcore")
        CheckRestartForNormalGames()
    else
        CheckRestartForHardcore()

    LoadGame()

    i := 1
    while (i <= RecordedSteps.MaxIndex()) {
        CheckDisconnectedPeriodic()  

        step := RecordedSteps[i]
        
        if (i > 10)
        {
            CheckForSkip()
        }

        if (RegExMatch(step, "i)UpgradeTower\s*\(\s*([^\s,)]+)\s*\)", m)) {
            currentID := m1
            success := UpgradeTower(currentID, false)
            i++
            if (success) {
                while (i <= RecordedSteps.MaxIndex()) {
                    nextStep := RecordedSteps[i]
                    if (RegExMatch(nextStep, "i)UpgradeTower\s*\(\s*([^\s,)]+)\s*\)", m2) && (m21 = currentID)) {
                        success := UpgradeTower(currentID, true)
                        if (!success) {
                            i++
                            break
                        }
                        i++
                    } else {
                        break
                    }
                }
            }
            Click, %unfocusX%, %unfocusY%
            Sleep, 50
        } else {
            try {
                ExecuteStep(step)
            } catch e {
                LogToConsole("ERROR executing step " i ": " step)
            }
            i++
        }
        Sleep, 50
    }

    LogToConsole("All strategy steps completed, entering maintenance loop...")
    Loop {
        Sleep, 500
        CheckForSkip()
        CheckDisconnectedPeriodic()
    }
}


ExecuteStep(step) {
    global
    step := RegExReplace(step, "\s*;.*$", "")
    step := Trim(step)
    if (step = "")
        return
    if (RegExMatch(step, "i)SpawnTower\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d)\s*,\s*([^\s,)]+)\s*\)", m)) {
        SpawnTower(m1, m2, m3, m4)
        return
    }
    if (RegExMatch(step, "i)UpgradeTower\s*\(\s*([^\s,)]+)\s*\)", m)) {
        UpgradeTower(m1)
        return
    }
    if (RegExMatch(step, "i)SetDJTrack\s*\(\s*(.+?)\s*\)", m)) {
        track := Trim(m1, " """)
        if (track != "") {
            SetDJTrack(track)
        }
        return
    }
    if (RegExMatch(step, "i)Commander\s*:=\s*true")) {
        Commander := true
        return
    }
    if (RegExMatch(step, "i)SellTower\s*\(\s*([^\s,)]+)\s*\)", m)) {
        SellTower(m1)
        return
    }
}

CheckDisconnectedPeriodic() {
    global LastDisconnectCheck
    if (A_TickCount - LastDisconnectCheck > 60000) {
        LastDisconnectCheck := A_TickCount
        LogToConsole("checking disconnect...")
        
        if !WinExist("ahk_exe RobloxPlayerBeta.exe") {
            LogToConsole("Roblox not running! Reloading...")
            Reload
        }
        
        CheckDisconnected()
    }
}
CheckDisconnected() {
    ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *15 Resources\Disconnected.png
    if (ErrorLevel = 0)
        Reload
}

CheckRestartForNormalGames() {
    global MoveEnabled, MoveDirection, MoveDuration 
    processName := "ahk_exe RobloxPlayerBeta.exe"
    if WinExist(processName) {
        WinActivate, %processName%
        Sleep, 500
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *20 Resources\Restart.png
        if (ErrorLevel = 0) {
            Click, % (FoundX + 80) " " (FoundY + 20)
            Sleep, 150
        } else {
            RunRoblox()
            JoinGame(difficulty)
        }
    } else {
        RunRoblox()
        JoinGame(difficulty)
    }
}

CheckRestartForHardcore() {
    if WinExist("ahk_exe RobloxPlayerBeta.exe") {
        WinActivate, ahk_exe RobloxPlayerBeta.exe
        sleep, 1500
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *10 Resources/Restart.png
        if (ErrorLevel = 1) {
            RunRoblox()
            JoinHardcore()
        }
        if (ErrorLevel = 0) {
            targetX := FoundX + 80
            targetY := FoundY + 20
            click, %targetX%, %targetY%
        }
    } else {
        RunRoblox()
        JoinHardcore()
    }
}

RunRoblox() {
    global VipLink, UseVipServer
    
    PlaceID := "3260590327"
    
    if (UseVipServer = "ON" && VipLink != "") {
        vipCode := ""
        
        if (InStr(VipLink, "privateServerLinkCode=")) {
            RegExMatch(VipLink, "privateServerLinkCode=([a-fA-F0-9]+)", found)
            vipCode := found1
            
            DeepLink := "roblox://placeID=" . PlaceID . "&linkcode=" . vipCode
            
        } else if (InStr(VipLink, "share?code=")) {
            RegExMatch(VipLink, "code=([a-fA-F0-9]+)", found)
            vipCode := found1
            
            DeepLink := "roblox://navigation/share_links?code=" . vipCode . "&type=Server"
        } else {
            DeepLink := "roblox://placeID=" . PlaceID
        }
    } else {
        DeepLink := "roblox://placeID=" . PlaceID
    }
    
    Run, %DeepLink%, , , outputPID
    
    WinWait, ahk_exe RobloxPlayerBeta.exe, , 15
    if !ErrorLevel {
        WinActivate, ahk_exe RobloxPlayerBeta.exe
        ExitFullScreen()
        WinMinimize, ahk_exe RobloxPlayerBeta.exe
        WinMaximize, ahk_exe RobloxPlayerBeta.exe
    } else {
        LogToConsole("ERROR: Roblox not started!")
        Sleep, 5000
        Reload
    }
    
    Sleep, 25000
    Loop {
        CheckDisconnectedPeriodic()
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *25 %A_WorkingDir%/Resources/Play.png
        if (ErrorLevel = 0)
            break
        if (ErrorLevel = 1) {
            ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *25 %A_WorkingDir%/Resources/Claim.png
            if (ErrorLevel = 0)
                click, %FoundX%, %FoundY%
        }
        Sleep, 1500
    }
    LogToConsole("Joining " difficulty "...")
}


ExitFullScreen() {
    if WinExist("ahk_exe RobloxPlayerBeta.exe") {
        WinActivate, ahk_exe RobloxPlayerBeta.exe
        WinGet, Style, Style, ahk_exe RobloxPlayerBeta.exe
        if !(Style & 0xC00000) {
            Send, {F11}
            Sleep, 500
        }
        WinRestore, ahk_exe RobloxPlayerBeta.exe
    }
}


JoinGame(diff) {
    Click, 968 871
    Sleep, 2500

    if (diff = "Pizza Party" || diff = "Badlands II" || diff = "Polluted Wastelands II")
        Click, 1209 531
    else
        Click, 982 574

    sleep, 1500
    if (diff = "Easy")
        Click, 361 546
    else if (diff = "Casual")
        Click, 594 555
    else if (diff = "Intermediate")
        Click, 842 558
    else if (diff = "Molten")
        Click, 1070 537
    else if (diff = "Fallen")
        Click, 1317 565
    else if (diff = "Frost")
        Click, 1566 573
    else if (diff = "Pizza Party")
        Click, 1184 557
    else if (diff = "Badlands II")
        Click, 757 568
    else if (diff = "Polluted Wastelands II")
        Click, 964 565

    Sleep, 1500
    Click, 795 462

    if (diff != "Pizza Party" && diff != "Badlands II" && diff != "Polluted Wastelands II")
    {
        sleep, 3000
        Loop {
            CheckDisconnectedPeriodic()
            ImageSearch, FoundX, FoundY, 749, 762, 1214, 931, *5 Resources/Ready.png
            if (ErrorLevel = 0)
                break
            Sleep, 100
        }
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *25 Resources/WrongCamera.png
        if (ErrorLevel = 0) {
            Send {Left Down}
            Sleep, 1500
            Send {Left Up}
        }
        SelectMap()
    }
}

JoinHardcore() {
    Click, 968 871 ; play btn
    Sleep, 1000
    Click, 498 540
    Sleep, 800
    
    if (difficulty = "Hardcore")
    {
        Click, 858 541 
    } else {
        Click, 1102 576
    }

    sleep, 600
    Click, 781 467
    sleep, 3000
    Loop {
        CheckDisconnectedPeriodic()
        ImageSearch, FoundX, FoundY, 749, 762, 1214, 931, *10 Resources/Ready.png
        if (ErrorLevel = 0)
            break
        Sleep, 100
    }
    SelectMap()
}

SelectMap() {
    global map, difficulty, modifiers
    
    LogToConsole("Selecting map: " map)

    sleep, 400

    if (difficulty = "Hardcore" or difficulty = "Voidcore")
    {   
        FoundColor := false

        Loop, 10 {
            PixelSearch, FoundX, FoundY, 643, 255, 1455, 768, 0x8E5EFF, 25, Fast
            
            if (ErrorLevel = 0) {
                FoundColor := true
                break
            }
            
            Sleep, 400
        }

        if (!FoundColor) {
            LogToConsole("Wrong camera position!")
            Sleep, 200
            SendEvent, {Left down}
            Sleep, 1500
            SendEvent, {Left up}
            Sleep, 50
        }

        Sleep, 200
        SendEvent, {w down}
        Sleep, 2800
        SendEvent, {w up}
        Sleep, 300
        
        TempSlotFile = %A_Temp%\tds_macro_slot.txt
        FileDelete, %TempSlotFile%
        
        LogToConsole("Trying to find: " map ". Please wait..")

        Map_Detector = "%MapDetectorPath%" "slot" "%map%"
        RunWait, %Map_Detector%, , Hide

        FileRead, FoundSlot, %TempSlotFile%
        FileDelete, %TempSlotFile%
        FoundSlot := Trim(FoundSlot)

        if (FoundSlot = "" or FoundSlot = 0)
        {
            LogToConsole("Map is not found! Reloading..." FoundSlot)
            Sleep, 1000
            Reload
        }
        LogToConsole("Found in slot " . FoundSlot)

        Sleep, 300

        SendEvent, {w down}
        Sleep, 1000 
        SendEvent, {w up}
        Sleep, 200

        if (FoundSlot = 1) { 
            SendEvent, {a down}
            Sleep, 1400 
            SendEvent, {a up} 
            Sleep, 600
        }
        else if (FoundSlot = 2) { 
            SendEvent, {a down}
            Sleep, 500  
            SendEvent, {a up} 
            Sleep, 600
        }
        else if (FoundSlot = 3) { 
            SendEvent, {d down}
            Sleep, 500  
            SendEvent, {d up} 
            Sleep, 600
        }
        else if (FoundSlot = 4) { 
            SendEvent, {d down}
            Sleep, 1400 
            SendEvent, {d up} 
            Sleep, 600
        }

        SendEvent, {e down}
        Sleep, 1000
        SendEvent, {e up} 
        Sleep, 100

        Click, 968, 871
        Sleep, 10000
    } else {
        
        Send {w down}
        Sleep, 2200
        Send {w up}
        Sleep, 500
        
        ; D
        Send {d down}
        Sleep, 1700
        Send {d up}
        Sleep, 500
        
        ; E
        Send {e down}
        Sleep, 1000
        Send {e up}
        Sleep, 500
        
        Click, 840, 251
        Sleep, 200
        SetKeyDelay, 0, 20
        Loop, Parse, map
        {
            SendEvent, %A_LoopField%
            Sleep, 30
        }
        SetKeyDelay, 0, 50
        Sleep, 300
        Click, 748, 360
        Sleep, 700
        
        PixelSearch, FoundX, FoundY, 840, 250, 1100, 450, 0x0000EC, 3, Fast
        if (ErrorLevel = 0) {
            Reload
            Sleep, 400
        }
        
        if (modifiers != "") {
            LogToConsole("Setting up modifiers: " modifiers)
            Click, 59, 1014
            Sleep, 300

            Loop, Parse, modifiers, `,
            {
                modifier := Trim(A_LoopField)
                if (modifier = "")
                    continue
                    
                Click, 881, 295
                Sleep, 200
                Send, ^a
                Sleep, 50
                Send, %modifier%
                Sleep, 200
                Click, 958, 357
                Sleep, 300
                LogToConsole("Modifier added: " modifier)
            }
            Sleep, 100
            Click, 1125, 889
            LogToConsole("All modifiers configured")
        }
        
        Sleep, 200
        Send, {a down}
        Sleep, 1700
        Send, {a up}
        Sleep, 200
        Send, {w down}
        Sleep, 2500
        Send, {w up}
        Sleep, 200
        Send, {a down}
        Sleep, 1400
        Send, {a up}
        Sleep, 600
        
        Send, {e down}
        Sleep, 800
        Send, {e up}
        Sleep, 100
        Click, 968, 871
        Sleep, 10000
        
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *35 Resources\%map%.png
        if (ErrorLevel = 1) {
            LogToConsole("Wrong Map! Reloading script...")
            Sleep, 1000
            Reload
        }
    }

    Sleep, 100
}


LoadGame() {
    CheckDisconnected()
    Loop {
        CheckDisconnectedPeriodic() 
        PixelSearch, FoundX, FoundY, 691, 153, 1191, 260, 0x00EB2B, 3, Fast
        if (ErrorLevel = 0) {
            Sleep, 300
            AlignCamera()
            Sleep, 500
            if (UseTimeScale && difficulty != "Pizza Party" && difficulty != "Badlands II" && difficulty != "Polluted Wastelands II") {
                if (difficulty = "Hardcore" or difficulty = "Voidcore")
                {
                    TimescaleX := 726
                    TimescaleY := 1002
                } else {
                    TimescaleX := 658
                    TimescaleY := 1002
                }
                LogToConsole("Applying timescale: " TimeScaleMode)
                Click, %TimescaleX%, %TimescaleY%
                Sleep, 500
                PixelSearch, ErrX, ErrY, 840, 250, 1100, 450, 0x0000EC, 0, Fast
                if (ErrorLevel = 0) {
                    UseTimeScale := false
                    TimeScaleMultiplier := 1
                    TimeScaleMode := "OFF"
                    IniWrite, %TimeScaleMode%, %SettingsFile%, Options, TimeScaleMode
                } else {
                    if (TimeScaleMode = "2x") {
                        Click, 960, 631
                        Sleep, 300
                        Click, %TimescaleX%, %TimescaleY%
                        Sleep, 100
                        Click, %TimescaleX%, %TimescaleY%
                        Sleep, 300
                    } else if (TimeScaleMode = "1.5x") {
                        Click, 960, 631
                        Sleep, 200
                        Click, %TimescaleX%, %TimescaleY%
                        Sleep, 300
                    }
                }
            }
            Click, %FoundX%, %FoundY%
            break
        }
    }
}

AlignCamera() {
    global MoveEnabled, MoveDirection, MoveDuration
    LogToConsole("Aligning camera")
    MouseMove, 1339, 236
    Click, Right, Down
    MouseMove, 1339, 1200
    Click, Right, Up
    Sleep, 200
    Send, {o down}
    Sleep, 500
    Send, {o up}
    Sleep, 200
    if (MoveEnabled) {
        Send {%MoveDirection% down}
        Sleep, %MoveDuration%
        Send {%MoveDirection% up}
    }
}

SpawnTower(X, Y, slotNumber, towerID) {
    CheckDisconnected()
    CheckCritical()
    LogToConsole("Placing tower " towerID " (slot " slotNumber ") at x:" X " y:" Y "...")
    Towers[towerID] := {x: X, y: Y, slot: slotNumber, level: 0}
    slot1 := "800 1000"
    slot2 := "890 1000"
    slot3 := "980 1000"
    slot4 := "1070 1000"
    slot5 := "1160 1000"
    currentSlot := slot%slotNumber%
    Loop {
        CheckForSkip()
        Click, %currentSlot%
        Sleep, 100
        MouseMove, %X%, %Y%
        Sleep, 100
        Click
        Sleep, 300
        Send, {Q}
        Sleep, 100
        Click, %unfocusX%, %unfocusY%

        PixelSearch, FoundX, FoundY, 840, 250, 1100, 450, 0x0000EC, 0, Fast
        if (ErrorLevel = 1) {
            Click, %unfocusX%, %unfocusY%
            LogToConsole("Tower " towerID " placed successfully")
            break
        } else {
            LogToConsole("Tower " towerID " placement failed, retrying in 3.5s...")
            Sleep, 200
            CheckForSkip()
            Sleep, 3500
        }
    }
    CheckForSkip()
    UpdateTowerIndicator(towerID)
}


SellTower(towerID) {
    global Towers, unfocusX, unfocusY
    CheckDisconnected()
    
    if (!Towers[towerID]) {
        LogToConsole("ERROR: Tower " towerID " not found for selling!")
        return false
    }
    
    LogToConsole("Selling tower " towerID "...")
    
    targetX := Towers[towerID].x
    targetY := Towers[towerID].y
    
    Click, %targetX%, %targetY%
    Sleep, 400
    
    attempts := 0
    Loop {
        CheckForSkip()
        PixelSearch, FoundX, FoundY, 1257, 513, 1340, 574, 0x7E5C27, 5, Fast
        if (ErrorLevel = 1) {
            attempts++
            if (attempts > 15) {
                LogToConsole("ERROR: Tower " towerID " menu not found for selling")
                return false
            }
            
            Random, VariationY, -10, 10
            targetX := Towers[towerID].x
            targetY := Towers[towerID].y + VariationY
            Click, %targetX%, %targetY%
            Sleep, 400
            continue
        }
        
         MouseMove, %unfocusX%, %unfocusY%
         Sleep, 50
         Click, 796, 871
        Sleep, 50
        MouseMove, %unfocusX%, %unfocusY%
        LogToConsole("Tower " towerID " sold successfully")
    
        if (Towers[towerID].hwnd) {
            hwnd := Towers[towerID].hwnd
            WinClose, ahk_id %hwnd%
            Gui, Tower%towerID%:Destroy
         }
        Towers.Delete(towerID)
        return true
     
        break
    }
    
    Sleep, 50
    return false
}

UpgradeTower(towerID, skipOpen := false) {
    global Towers, unfocusX, unfocusY
    CheckDisconnected()
    if (!Towers[towerID]) {
        LogToConsole("ERROR: Tower " towerID " not found!")
        return false
    }
    CheckCritical()
    if (!skipOpen) {
        targetX := Towers[towerID].x, targetY := Towers[towerID].y
        CheckCritical()
        Click, %targetX%, %targetY%
        Sleep, 400
    }
    attempts := 0
    Loop {
        CheckCritical()
        if (skipOpen) {
            PixelSearch, MenuX, MenuY, 1257, 513, 1340, 574, 0x7E5C27, 5, Fast
            if (ErrorLevel) {
                targetX := Towers[towerID].x, targetY := Towers[towerID].y
                Click, %targetX%, %targetY%
                Sleep, 400
            }
        }
        PixelSearch, FoundX, FoundY, 1257, 513, 1340, 574, 0x7E5C27, 5, Fast
        if (ErrorLevel = 1) {
            attempts++
            if (attempts > 25) {
                LogToConsole("ERROR: Tower " towerID " menu not found after 25 attempts, respawning...")
                SpawnTower(Towers[towerID].x, Towers[towerID].y, Towers[towerID].slot, towerID)
                attempts := 0
                targetX := Towers[towerID].x, targetY := Towers[towerID].y
                Click, %targetX%, %targetY%
                Sleep, 400
                Continue
            }
            if (!skipOpen) {
                Random, VariationY, -10, 10
                targetX := Towers[towerID].x, targetY := Towers[towerID].y + VariationY
                Click, %targetX%, %targetY%
            }
            continue
        }
        PixelSearch, FoundX, FoundY, 1106, 624, 1251, 651, 0x346120, 25, Fast RGB
        if (ErrorLevel = 0) {
            upgradeAttempts := 0
            Loop {
                Click, 1100, 600
                Sleep, 400
                PixelSearch, ErrX, ErrY, 840, 250, 1100, 450, 0x0000EC, 0, Fast
                if (ErrorLevel = 0) {
                    Sleep, 4400
                    upgradeAttempts++
                    if (upgradeAttempts > 20) {
                        LogToConsole("ERROR: Tower " towerID " upgrade failed after 20 attempts")
                        Click, %unfocusX%, %unfocusY%
                        Sleep, 100
                        return false
                    }
                    LogToConsole("Tower " towerID " upgrade error, waiting 4.4s...")
                    continue
                }
                break
            }
            Towers[towerID].level += 1
            LogToConsole("Tower " towerID " upgraded to level " Towers[towerID].level)
            UpdateTowerIndicator(towerID)
            if (Towers[towerID].level >= 2 && RegExMatch(towerID, "i)^Commander\d*$") && !Commander) {
                Commander := true
                LogToConsole("Commander mode activated (tower " towerID " level " Towers[towerID].level ")")
                if (Recording && !HasStep("Commander := true"))
                    RecordedSteps.Push("Commander := true")
            }
            return true
        }
    }
}

CheckCritical() {
    CheckDisconnected()
    PixelSearch, FoundX, FoundY, 562, 325, 1404, 456, 0x213DFF, 0, Fast
    if (ErrorLevel = 0)
        Reload
    ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *25 Resources\triumph.png
    if (ErrorLevel = 0)
        Reload
    if (ErrorLevel = 1) {
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *25 Resources\PlayAgain.png
        if (ErrorLevel = 0)
            Reload
    }
    ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *30 Resources\YouLost.png
    if (ErrorLevel = 0)
        Reload
}

CheckForSkip() {
    global ChainKey, BeatKey, CaravanKey, TimeScaleMultiplier, UseTimeScale, AutoSkip, autoChain, autoCaravan, autoDropTheBeat, Commander, unfocusX, unfocusY, chainInterval, caravanInterval
    CheckDisconnected()
    CheckDisconnectedPeriodic()
    Send, {Q}

    ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *80 Resources\triumph.png
    if (ErrorLevel = 0) {
        LogToConsole("Victory detected! Reloading...")
        Reload
    }

    if (ErrorLevel = 1) {
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *80 Resources\PlayAgain.png
        if (ErrorLevel = 0) {
            LogToConsole("Defeat detected! Reloading...")
            Reload
        }
    }

    ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *80 Resources\YouLost.png
    if (ErrorLevel = 0) {
        LogToConsole("Game over detected! Reloading...")
        Reload
    }

    PixelSearch, FoundX, FoundY, 562, 325, 1404, 456, 0x213DFF, 0, Fast
    if (ErrorLevel = 0) {
        LogToConsole("Disconnected detected! Reloading...")
        Reload
    }

    if (AutoSkip = "OFF") {
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *10 Resources\DontSkip.png
        if (ErrorLevel = 0) {
            TargetX := FoundX + 10
            TargetY := FoundY + 20
            MouseMove, %unfocusX%, %unfocusY%
            Sleep, 50
            Click, %TargetX%, %TargetY%
            MouseMove, %unfocusX%, %unfocusY%
            Sleep, 100
            LogToConsole("Wave skipped (auto-skip OFF)")
        }
    }
    if (AutoSkip = "ON") {
        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *10 Resources\Skip.png
        if (ErrorLevel = 0) {
            TargetX := FoundX + 10
            TargetY := FoundY + 20
            MouseMove, %unfocusX%, %unfocusY%
            Sleep, 50
            Click, %TargetX%, %TargetY%
            MouseMove, %unfocusX%, %unfocusY%
            Sleep, 100
            LogToConsole("Wave skipped (auto-skip ON)")
        }
    }

    static LastChainTime := 0
    static LastDropTime := 0
    static LastCaravanTime := 0

    if (autoChain = "ON" && Commander && (A_TickCount - LastChainTime > chainInterval * 1000 / TimeScaleMultiplier)) {
        LastChainTime := A_TickCount
        Click, %unfocusX%, %unfocusY%
        Sleep, 100
        Send, {%ChainKey%}
        Sleep, 300
        PixelSearch, FoundX, FoundY, 840, 250, 1100, 450, 0xFF0000, 20, Fast RGB
        if (ErrorLevel = 0) {
            LogToConsole("Chain ability used, cooldown error detected, waiting 4.5s...")
            Sleep, 4500
        } else {
            LogToConsole("Chain ability activated")
        }
    }

    if (autoCaravan = "ON" && Commander && (A_TickCount - LastCaravanTime > caravanInterval * 1000 / TimeScaleMultiplier)) {
        LastCaravanTime := A_TickCount
        Click, %unfocusX%, %unfocusY%
        Sleep, 100
        Send, {%CaravanKey%}
        Sleep, 300
        PixelSearch, FoundX, FoundY, 840, 250, 1100, 450, 0xFF0000, 20, Fast RGB
        if (ErrorLevel = 0) {
            LogToConsole("Caravan ability used, cooldown error detected, waiting 4.5s...")
            Sleep, 4500
        } else {
            LogToConsole("Caravan ability activated")
        }
    }

    if (autoDropTheBeat = "ON" && Towers["DJ"] && (A_TickCount - LastDropTime > 30000 / TimeScaleMultiplier)) {
        LastDropTime := A_TickCount
        Click, %unfocusX%, %unfocusY%
        Sleep, 100
        Send, {%BeatKey%}
        Sleep, 300
        PixelSearch, FoundX, FoundY, 840, 250, 1100, 450, 0xFF0000, 20, Fast RGB
        if (ErrorLevel = 0) {
            LogToConsole("Drop the Beat used, cooldown error detected, waiting 4.5s...")
            Sleep, 4500
        } else {
            LogToConsole("Drop the Beat activated")
        }
    }
}

SetDJTrack(track) {
    CheckDisconnected()
    if (Towers["DJ"]) {
        LogToConsole("Setting DJ track to " track "...")
        targetX := Towers["DJ"].x, targetY := Towers["DJ"].y
        Click, %targetX%, %targetY%
        Sleep, 400
        Loop {
            CheckForSkip()
            PixelSearch, FoundX, FoundY, 1257, 513, 1340, 574, 0x7E5C27, 5, Fast
            if (ErrorLevel = 1) {
                Random, VariationY, -10, 10
                targetX := Towers["DJ"].x, targetY := Towers["DJ"].y + VariationY
                Click, %targetX%, %targetY%
                Sleep, 400
                continue
            }
            if (ErrorLevel = 0) {
                trackFound := false
                Loop, 3 {
                    if (track = "Red") {
                        if (Towers["DJ"].level >= 3) {
                            sleep, 400
                            Click, 1585, 682
                            Sleep, 100
                            Click, %unfocusX%, %unfocusY%
                            trackFound := true
                            LogToConsole("DJ track set to Red")
                            break
                        } else {
                            ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *25 Resources\Green.png
                            if (ErrorLevel = 0) {
                                targX := FoundX + 70
                                Click, %targX%, %FoundY%
                                Sleep, 100
                                Click, %unfocusX%, %unfocusY%
                                trackFound := true
                                LogToConsole("DJ track set to Green (Red not available)")
                                break
                            }
                        }
                    } else {
                        ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, *20 Resources\%track%.png
                        if (ErrorLevel = 0) {
                            Click, %FoundX%, %FoundY%
                            Sleep, 100
                            Click, %unfocusX%, %unfocusY%
                            trackFound := true
                            LogToConsole("DJ track set to " track)
                            break
                        }
                    }
                    if (A_Index < 3)
                        Sleep, 400
                }
                if (trackFound)
                    break
            }
        }
    } else {
        LogToConsole("ERROR: DJ tower not found!")
    }
}

FindClosestTower(mx, my) {
    global Towers
    closestID := ""
    minDist := 20
    for id, t in Towers {
        dist := Sqrt((t.x - mx)**2 + (t.y - my)**2)
        if (dist < minDist) {
            minDist := dist
            closestID := id
        }
    }
    return closestID
}

HasStep(searchStep) {
    global RecordedSteps
    for i, s in RecordedSteps
        if (s = searchStep)
            return true
    return false
}

UpdateTowerIndicator(towerID) {
    global Towers, Recording, ShowIndicators
    if (!Recording || !ShowIndicators || !Towers[towerID])
        return
    level := Towers[towerID].level
    if (Towers[towerID].hwnd) {
        hwnd := Towers[towerID].hwnd
        ControlSetText, Static1, %level%, ahk_id %hwnd%
        WinShow, ahk_id %hwnd%
    } else {
        Gui, Tower%towerID%:New, +ToolWindow +AlwaysOnTop -Caption +E0x20, Tower%towerID%
        Gui, Color, FFFFFF
        Gui, Font, s10 cBlack, Arial
        Gui, Add, Text, x0 y0 w24 h24 Center 0x200, %level%
        WinSet, TransColor, FFFFFF 255, Tower%towerID%
        x := Towers[towerID].x - 12
        y := Towers[towerID].y - 12
        Gui, Show, x%x% y%y% w24 h24 NoActivate, Tower%towerID%
        WinGet, hwnd, ID, Tower%towerID%
        Towers[towerID].hwnd := hwnd
    }
}

DeleteAllIndicators() {
    global Towers
    for id, t in Towers {
        if (t.hwnd) {
            hwnd := t.hwnd
            WinClose, ahk_id %hwnd%
        }
        Gui, Tower%id%:Destroy
    }
    for id, t in Towers
        Towers[id].hwnd := ""
}

GetNextNumericID() {
    global Towers
    maxNum := 0
    for id, t in Towers {
        if (id ~= "^\d+$") {
            num := id + 0
            if (num > maxNum)
                maxNum := num
        }
    }
    return maxNum + 1
}

ModernMsgBox(Title, Text, Buttons="OK", AccentColor="Blue") {
    global MsgResult := ""
    static hMsgGui
    
    SoundPlay, *48 
    HexColor := (AccentColor = "Orange") ? "FF8C00" : "0078D7"
    
    Gui, Msg:New, +AlwaysOnTop -Caption +Border +LastFound +HwndhMsgGui
    Gui, Color, 1E1E1E
    
    Gui, Font, s14 w700 c%HexColor%, Segoe UI
    Gui, Add, Text, x25 y20 w350, %Title%
    
    Gui, Font, s11 w400 cFFFFFF
    Gui, Add, Text, x25 y+15 w350, %Text%
    
    Gui, Font, s10 w600 cFFFFFF
    if (Buttons = "OK") {
        Gui, Add, Button, x135 y+30 w130 h40 gMsgOK Default, OK
    } else {
        Gui, Add, Button, x30 y+30 w165 h40 gMsgYES Default Section, YES
        Gui, Add, Button, x205 ys w165 h40 gMsgNO, NO
    }
    
    Gui, Add, Text, x25 y+20 w350 h1 +Hidden, .
    Gui, Show, w400 AutoSize, %Title%
    
    MsgResult := ""
    while (MsgResult = "") {
        Sleep, 100
        if !WinExist("ahk_id " hMsgGui)
            break
    }
    return MsgResult

    MsgOK:
    MsgYES:
        MsgResult := "YES"
        GoSub, MsgCloseAnim
    return

    MsgNO:
        MsgResult := "NO"
        GoSub, MsgCloseAnim
    return

    MsgCloseAnim:
        Gui, Msg:Destroy
    return
}

SyncSettings() {
    global SettingsFile, AppDataSettingsPath, LocalSettingsPath
    global VipLink, UseVipServer
    
    IniRead, VipLink, %SettingsFile%, Options, VipLink, %A_Space%
    IniRead, tempVip, %SettingsFile%, Options, UseVipServer, OFF
    UseVipServer := (tempVip = "ON" || tempVip = "1") ? "ON" : "OFF"
    
    if (SettingsFile = AppDataSettingsPath) {
        FileCopy, %AppDataSettingsPath%, %LocalSettingsPath%, 1
    } else {
        SplitPath, AppDataSettingsPath,, AppDir
        IfNotExist, %AppDir%
            FileCreateDir, %AppDir%
        FileCopy, %LocalSettingsPath%, %AppDataSettingsPath%, 1
    }
}

global OverlayPicHWND  

ShowDebugConsole() {
    global DebugConsole, OverlayHWND, OverlayBitmap, OverlayGraphics, OverlayPicHWND, OverlayX, OverlayY, OverlayWidth, OverlayHeight
    if (DebugConsole != "ON")
        return
    if (OverlayHWND && WinExist("ahk_id " OverlayHWND))
        return

    Gui, Overlay:New, +AlwaysOnTop +ToolWindow -Caption +E0x20 +LastFound +HwndOverlayHWND
    Gui, Color, 0
    Gui, Add, Picture, x0 y0 w%OverlayWidth% h%OverlayHeight% +0xE +HwndOverlayPicHWND
    WinSet, ExStyle, +0x8000000, ahk_id %OverlayHWND%
    Gui, Show, x%OverlayX% y%OverlayY% w%OverlayWidth% h%OverlayHeight% NA, DebugOverlay
    WinSet, TransColor, 0, ahk_id %OverlayHWND%

    OverlayBitmap := Gdip_CreateBitmap(OverlayWidth, OverlayHeight)
    OverlayGraphics := Gdip_GraphicsFromImage(OverlayBitmap)
    Gdip_SetSmoothingMode(OverlayGraphics, 4)
}
HideDebugConsole() {
    global OverlayHWND, OverlayBitmap, OverlayGraphics, OverlayPicHWND
    if (OverlayBitmap) {
        Gdip_DisposeImage(OverlayBitmap)
        OverlayBitmap := ""
    }
    if (OverlayGraphics) {
        Gdip_DeleteGraphics(OverlayGraphics)
        OverlayGraphics := ""
    }
    Gui, Overlay:Destroy
    OverlayHWND := ""
    OverlayPicHWND := ""
}

UpdateOverlay() {
    global OverlayBitmap, OverlayGraphics, OverlayPicHWND, LogLines, OverlayWidth, OverlayHeight
    if !OverlayGraphics
        return

    Gdip_GraphicsClear(OverlayGraphics, 0x00000000)

    fontName := "Consolas"
    fontSize := 14
    style := 1
    textColor := 0xFFFFFFFF    

    hFamily := Gdip_FontFamilyCreate(fontName)
    hFont := Gdip_FontCreate(hFamily, fontSize, style)
    hFormat := Gdip_StringFormatCreate(0x0000)
    Gdip_SetStringFormatAlign(hFormat, 0)

    pBrushText := Gdip_BrushCreateSolid(textColor)
    pBrushBg := Gdip_BrushCreateSolid(0xAA000000)

    maxLines := Floor(OverlayHeight / (fontSize * 1.4))
    startIndex := Max(1, LogLines.MaxIndex() - maxLines + 1)
    yPos := 5
    maxWidth := OverlayWidth - 20

    wrappedLines := []
    Loop, % maxLines {
        index := startIndex + A_Index - 1
        if (index > LogLines.MaxIndex())
            break
        line := LogLines[index]
        
        tempLines := []
        while (StrLen(line) > 0) {
            if (StrLen(line) * fontSize * 0.6 <= maxWidth) {
                tempLines.Push(line)
                break
            }
            cutPos := Floor(maxWidth / (fontSize * 0.6))
            tempLines.Push(SubStr(line, 1, cutPos))
            line := SubStr(line, cutPos + 1)
        }
        
        for i, wrappedLine in tempLines {
            wrappedLines.Push(wrappedLine)
        }
    }

    while (wrappedLines.MaxIndex() > maxLines)
        wrappedLines.RemoveAt(1)

    for i, line in wrappedLines {
        Gdip_FillRectangle(OverlayGraphics, pBrushBg, 5, yPos, OverlayWidth-10, fontSize * 1.4)
        CreateRectF(RC, 5, yPos, OverlayWidth-5, fontSize * 1.4)
        Gdip_DrawString(OverlayGraphics, line, hFont, hFormat, pBrushText, RC)
        yPos += fontSize * 1.4
    }

    Gdip_DeleteBrush(pBrushText)
    Gdip_DeleteBrush(pBrushBg)
    Gdip_DeleteStringFormat(hFormat)
    Gdip_DeleteFont(hFont)
    Gdip_DeleteFontFamily(hFamily)

    hBitmap := Gdip_CreateHBITMAPFromBitmap(OverlayBitmap)
    SetImage(OverlayPicHWND, hBitmap)
    DeleteObject(hBitmap)
}

LogToConsole(text) {
    global DebugConsole, LogLines, OverlayHWND
    if (DebugConsole != "ON")
        return

    FormatTime, time,, HH:mm:ss
    LogLines.Push("[" . time . "] " . text)

    while (LogLines.MaxIndex() > 500)
        LogLines.RemoveAt(1)

    if (OverlayHWND && WinExist("ahk_id " OverlayHWND))
        UpdateOverlay()
}

GuiClose:
ExitApp
Return

CleanupGdip:
    Gdip_Shutdown(pToken)
ExitApp

